#!/usr/bin/env python3
"""
Deauth Detection Dashboard — Flask + SocketIO Backend
Run: sudo python3 app.py -i wlan0mon --webcam 192.168.1.100
"""

import argparse
import threading
import signal
import sys
import logging
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO

from core.monitor import WiFiMonitor
from core.device_tracker import DeviceTracker
from core.alert_store import AlertStore
from utils.logger import setup_logger

# ── Flask + SocketIO setup ──────────────────────────────────────────
app = Flask(__name__)
app.config["SECRET_KEY"] = "deauth-detector-2025"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# Globals (set after arg parse)
alert_store   = AlertStore()
device_tracker = None
monitor        = None
logger         = None


# ── Routes ──────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/alerts")
def api_alerts():
    return jsonify(alert_store.get_all())


@app.route("/api/devices")
def api_devices():
    return jsonify(device_tracker.get_all() if device_tracker else [])


@app.route("/api/stats")
def api_stats():
    return jsonify(alert_store.get_stats())


@app.route("/api/clear")
def api_clear():
    alert_store.clear()
    socketio.emit("alerts_cleared", {})
    return jsonify({"status": "ok"})


# ── SocketIO events ─────────────────────────────────────────────────
@socketio.on("connect")
def on_connect():
    # Send current state to newly connected browser
    socketio.emit("init_alerts",  alert_store.get_all())
    if device_tracker:
        socketio.emit("init_devices", device_tracker.get_all())


# ── Public emit helpers (called by monitor/tracker threads) ─────────
def emit_alert(alert_dict):
    alert_store.add(alert_dict)
    socketio.emit("new_alert", alert_dict)


def emit_device_update(device_dict):
    socketio.emit("device_update", device_dict)


# ── Entry point ─────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(description="Deauth Detection Dashboard")
    p.add_argument("-i", "--interface", required=True,
                   help="Monitor-mode interface (e.g. wlan0mon)")
    p.add_argument("--webcam", default=None,
                   help="IP of webcam to track (e.g. 192.168.1.100)")
    p.add_argument("--devices", nargs="*", default=[],
                   help="Extra device IPs to track e.g. --devices 192.168.1.101 192.168.1.102")
    p.add_argument("--threshold", type=int, default=10)
    p.add_argument("--window",    type=int, default=5)
    p.add_argument("--baseline-period", type=int, default=15)
    p.add_argument("--port", type=int, default=5000)
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args()


def main():
    global device_tracker, monitor, logger

    args   = parse_args()
    logger = setup_logger("logs/dashboard.log", args.verbose)

    # Build device list
    tracked_ips = []
    if args.webcam:
        tracked_ips.append({"ip": args.webcam, "label": "IP Webcam", "icon": "📷"})
    for ip in args.devices:
        tracked_ips.append({"ip": ip, "label": f"Device {ip}", "icon": "📡"})

    # Device tracker (pings devices, emits status changes)
    device_tracker = DeviceTracker(
        devices=tracked_ips,
        emit_fn=emit_device_update,
        logger=logger,
    )
    device_tracker.start()

    # WiFi monitor (sniffs deauth frames, runs 5 detectors)
    monitor = WiFiMonitor(
        interface=args.interface,
        threshold=args.threshold,
        window=args.window,
        baseline_period=args.baseline_period,
        emit_fn=emit_alert,
        logger=logger,
    )

    # Start monitor in background thread
    mon_thread = threading.Thread(target=monitor.start, daemon=True)
    mon_thread.start()

    def shutdown(sig, frame):
        logger.info("Shutting down...")
        monitor.stop()
        device_tracker.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    logger.info(f"Dashboard running at http://0.0.0.0:{args.port}")
    logger.info(f"Open in browser: http://<this-pc-ip>:{args.port}")

    socketio.run(app, host="0.0.0.0", port=args.port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
