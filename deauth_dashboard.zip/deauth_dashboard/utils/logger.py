"""Logger setup utility."""

import logging
import os


def setup_logger(log_file="logs/detections.log", verbose=False):
    os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)

    level = logging.DEBUG if verbose else logging.INFO

    logger = logging.getLogger("deauth_detector")
    logger.setLevel(logging.DEBUG)  # capture everything internally

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S"))
    logger.addHandler(ch)

    # File handler — always logs at INFO+
    fh = logging.FileHandler(log_file)
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)

    return logger
