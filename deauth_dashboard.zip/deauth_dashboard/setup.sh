#!/usr/bin/env bash
# setup.sh — installs all dependencies for the dashboard detector
# Usage: sudo bash setup.sh <interface> <webcam-ip>
# Example: sudo bash setup.sh wlan0 192.168.1.100

set -e

IFACE="${1:-wlan0}"
WEBCAM_IP="${2:-}"

echo "===================================================="
echo " Deauth Dashboard — Ubuntu Setup"
echo " Interface : $IFACE"
echo " Webcam IP : ${WEBCAM_IP:-not set}"
echo "===================================================="

# System packages
echo "[1/4] System packages..."
apt-get update -qq
apt-get install -y python3 python3-pip aircrack-ng iw wireless-tools tcpdump iputils-ping

# Python packages
echo "[2/4] Python packages..."
pip3 install flask flask-socketio scapy eventlet --break-system-packages

# Logs dir
echo "[3/4] Creating logs directory..."
mkdir -p logs

# Monitor mode
echo "[4/4] Enabling monitor mode on $IFACE..."
airmon-ng check kill 2>/dev/null || true
airmon-ng start "$IFACE" 2>/dev/null || true

MON="${IFACE}mon"

echo ""
echo "===================================================="
echo " Setup complete!"
echo ""
echo " START THE DASHBOARD:"
if [ -n "$WEBCAM_IP" ]; then
  echo "   sudo python3 app.py -i $MON --webcam $WEBCAM_IP --baseline-period 10"
else
  echo "   sudo python3 app.py -i $MON --baseline-period 10"
  echo "   # Add --webcam <IP> to track your IP camera"
fi
echo ""
echo " Then open in browser (from ANY device on the network):"
echo "   http://$(hostname -I | awk '{print $1}'):5000"
echo "===================================================="
