"""
Detection Method 4: Rapid Sequence Detection
Accuracy: 80% | Energy Cost: Low

Analyzes timing patterns between consecutive deauth frames.
Attack tools (aireplay-ng, mdk4) send frames in very rapid,
regular bursts. This detector identifies micro-burst patterns
by measuring inter-frame gaps and sequence regularity.

Key signals:
  - Many frames from the same source with tiny inter-frame gaps
  - Highly regular (low-jitter) timing — a signature of automated tools
"""

import statistics


class RapidSequenceDetector:
    name = "Rapid Sequence Detection"

    # If N or more frames arrive within this many ms between frames
    MIN_BURST_FRAMES  = 5
    MAX_INTER_FRAME_MS = 200   # 200ms between frames = rapid burst
    # Low jitter coefficient (std/mean) means machine-generated timing
    JITTER_THRESHOLD  = 0.5

    def __init__(self, window, logger):
        self.window = window
        self.logger = logger

    def analyze(self, frame, window_frames):
        src = frame["src"]

        # Get timestamps from the same source, sorted
        src_times = sorted(
            f["time"] for f in window_frames if f["src"] == src
        )

        if len(src_times) < self.MIN_BURST_FRAMES:
            self.logger.debug(
                f"[RapidSeqDetector] src={src} only {len(src_times)} frames — not enough"
            )
            return {"alert": False}

        # Compute inter-frame gaps in milliseconds
        gaps_ms = [
            (src_times[i+1] - src_times[i]) * 1000
            for i in range(len(src_times) - 1)
        ]

        avg_gap = sum(gaps_ms) / len(gaps_ms)
        rapid_gaps = [g for g in gaps_ms if g <= self.MAX_INTER_FRAME_MS]

        # Compute jitter (coefficient of variation)
        jitter = 0.0
        if len(gaps_ms) >= 2 and avg_gap > 0:
            try:
                jitter = statistics.stdev(gaps_ms) / avg_gap
            except statistics.StatisticsError:
                jitter = 0.0

        self.logger.debug(
            f"[RapidSeqDetector] src={src} frames={len(src_times)} "
            f"avg_gap={avg_gap:.1f}ms rapid={len(rapid_gaps)} jitter={jitter:.2f}"
        )

        # Alert if most gaps are rapid AND timing is regular (low jitter)
        burst_ratio = len(rapid_gaps) / len(gaps_ms) if gaps_ms else 0
        if burst_ratio >= 0.7 and jitter < self.JITTER_THRESHOLD:
            return {
                "alert"   : True,
                "severity": "HIGH",
                "detail"  : (
                    f"Rapid burst from {src}: {len(src_times)} frames, "
                    f"avg_gap={avg_gap:.0f}ms, jitter={jitter:.2f} "
                    f"(machine-like timing pattern)"
                ),
            }
        return {"alert": False}
