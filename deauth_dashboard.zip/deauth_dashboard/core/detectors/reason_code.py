"""
Detection Method 5: Reason Code Analysis
Accuracy: 88% | Energy Cost: Very Low

Checks deauth/disassoc reason codes defined in IEEE 802.11.
Legitimate APs use a small set of valid reason codes.
Attack tools commonly use:
  - Reason 1  (Unspecified) — most common in attacks
  - Reason 7  (Class 3 frame received from nonassociated STA)
  - Non-standard / invalid reason codes

Additionally, if the same reason code is repeated rapidly
from multiple sources, it strongly suggests scripted attacks.
"""


# Reason codes legitimately seen in normal operation
LEGITIMATE_REASONS = {
    2,   # Previous auth no longer valid
    3,   # Deauth because STA is leaving IBSS/ESS
    4,   # Inactivity timer
    5,   # AP unable to handle all stations
    8,   # STA leaving BSS
    34,  # Disassociated due to poor channel conditions (802.11h)
    36,  # Disassoc due to inactivity
    45,  # MIC failure
}

# Commonly abused / suspicious reason codes
SUSPICIOUS_REASONS = {
    0,   # Reserved — invalid
    1,   # Unspecified (most used by aireplay-ng / mdk)
    6,   # Class 2 frame from nonauth STA
    7,   # Class 3 frame from nonassoc STA
    9,   # STA requesting (re)assoc not auth
}

# If seen this many times in one window, flag regardless
SUSPICIOUS_REPEAT_THRESHOLD = 3


class ReasonCodeDetector:
    name = "Reason Code Analysis"

    def __init__(self, window, logger):
        self.window = window
        self.logger = logger

    def analyze(self, frame, window_frames):
        reason = frame["reason"]

        # Count occurrences of this exact reason code in window
        reason_count = sum(
            1 for f in window_frames if f["reason"] == reason
        )

        self.logger.debug(
            f"[ReasonCodeDetector] reason={reason} count_in_window={reason_count}"
        )

        # Direct hit: known suspicious reason code used repeatedly
        if reason in SUSPICIOUS_REASONS and reason_count >= SUSPICIOUS_REPEAT_THRESHOLD:
            return {
                "alert"   : True,
                "severity": "HIGH",
                "detail"  : (
                    f"Suspicious reason code {reason} "
                    f"({'Unspecified' if reason == 1 else 'Attack-common code'}) "
                    f"repeated {reason_count}× in {self.window}s window"
                ),
            }

        # Invalid / reserved reason code
        if reason == 0 or reason > 99:
            return {
                "alert"   : True,
                "severity": "MEDIUM",
                "detail"  : (
                    f"Invalid/reserved reason code {reason} — "
                    f"no legitimate AP sends this"
                ),
            }

        # Reason code not in any known-legitimate set
        if reason not in LEGITIMATE_REASONS and reason not in SUSPICIOUS_REASONS:
            if reason_count >= SUSPICIOUS_REPEAT_THRESHOLD:
                return {
                    "alert"   : True,
                    "severity": "MEDIUM",
                    "detail"  : (
                        f"Unknown reason code {reason} repeated "
                        f"{reason_count}× — not standard 802.11 behavior"
                    ),
                }

        return {"alert": False}
