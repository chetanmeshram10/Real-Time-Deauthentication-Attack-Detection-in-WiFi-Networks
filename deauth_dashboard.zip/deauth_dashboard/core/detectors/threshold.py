"""
Detection Method 1: Threshold Detection
Accuracy: 85% | Energy Cost: Very Low

Counts deauth frames within a sliding time window.
If count exceeds threshold, an attack is flagged.
Normal WiFi produces very few deauth frames organically.
"""


class ThresholdDetector:
    name = "Threshold Detection"

    def __init__(self, threshold, window, logger):
        self.threshold = threshold
        self.window    = window
        self.logger    = logger

    def analyze(self, frame, window_frames):
        count = len(window_frames)

        self.logger.debug(
            f"[ThresholdDetector] {count}/{self.threshold} frames in {self.window}s window"
        )

        if count >= self.threshold:
            return {
                "alert"   : True,
                "severity": "HIGH",
                "detail"  : (
                    f"{count} deauth frames in {self.window}s window "
                    f"(threshold={self.threshold})"
                ),
            }
        return {"alert": False}
