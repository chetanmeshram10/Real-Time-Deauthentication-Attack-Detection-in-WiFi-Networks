"""
Detection Method 3: Rate Anomaly Detection
Accuracy: 75% | Energy Cost: Low

Learns normal deauth frame rate during a baseline period,
then flags when current rate deviates by more than 3× the
standard deviation (Z-score approach).

This catches attacks that stay under absolute thresholds
but are still abnormally high compared to local baseline.
"""

import math
import time


class RateAnomalyDetector:
    name = "Rate Anomaly Detection"

    # Alert if current rate is > SIGMA_MULTIPLIER * std above baseline mean
    SIGMA_MULTIPLIER = 3.0
    # Minimum baseline frames needed before this detector is meaningful
    MIN_BASELINE_SAMPLES = 5

    def __init__(self, window, baseline_period, logger):
        self.window          = window
        self.baseline_period = baseline_period
        self.logger          = logger

        # Baseline stats
        self._baseline_rates = []  # frames-per-window samples during learning
        self._baseline_mean  = 0.0
        self._baseline_std   = 0.0
        self._ready          = False

        # Rate tracking during baseline
        self._baseline_window = []

    # Called during learning phase by monitor.py
    def record_baseline(self, frame_info):
        now = frame_info["time"]
        self._baseline_window.append(now)
        # Purge old frames from baseline window
        cutoff = now - self.window
        self._baseline_window = [t for t in self._baseline_window if t >= cutoff]
        # Sample the current rate
        self._baseline_rates.append(len(self._baseline_window))

        # Compute running stats
        if len(self._baseline_rates) >= self.MIN_BASELINE_SAMPLES:
            n    = len(self._baseline_rates)
            mean = sum(self._baseline_rates) / n
            variance = sum((r - mean) ** 2 for r in self._baseline_rates) / n
            self._baseline_mean = mean
            self._baseline_std  = math.sqrt(variance)
            self._ready         = True

    def analyze(self, frame, window_frames):
        if not self._ready:
            self.logger.debug("[RateAnomalyDetector] Baseline not ready yet — skipping")
            return {"alert": False}

        current_rate = len(window_frames)

        if self._baseline_std < 1e-6:
            # Near-zero std: flag anything above mean + 2
            threshold = self._baseline_mean + 2
        else:
            threshold = self._baseline_mean + self.SIGMA_MULTIPLIER * self._baseline_std

        z_score = (
            (current_rate - self._baseline_mean) / self._baseline_std
            if self._baseline_std > 1e-6
            else float("inf")
        )

        self.logger.debug(
            f"[RateAnomalyDetector] rate={current_rate} "
            f"baseline_mean={self._baseline_mean:.2f} "
            f"std={self._baseline_std:.2f} z={z_score:.2f} threshold={threshold:.2f}"
        )

        if current_rate > threshold:
            return {
                "alert"   : True,
                "severity": "MEDIUM",
                "detail"  : (
                    f"Rate anomaly: {current_rate} frames/window vs "
                    f"baseline {self._baseline_mean:.1f}±{self._baseline_std:.1f} "
                    f"(z-score={z_score:.1f})"
                ),
            }
        return {"alert": False}
