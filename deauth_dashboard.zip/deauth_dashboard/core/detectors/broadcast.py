"""
Detection Method 2: Broadcast Detection
Accuracy: 90% | Energy Cost: Very Low

Identifies deauth frames sent to the broadcast MAC address
(ff:ff:ff:ff:ff:ff). Legitimate APs NEVER send broadcast
deauths — this is a hallmark of tools like aireplay-ng / mdk3.
Even a single broadcast deauth is highly suspicious.
"""


BROADCAST_MAC = "ff:ff:ff:ff:ff:ff"


class BroadcastDetector:
    name = "Broadcast Detection"

    def __init__(self, window, logger):
        self.window = window
        self.logger = logger

    def analyze(self, frame, window_frames):
        dst = frame["dst"].lower()

        # Count broadcast frames in current window for context
        broadcast_count = sum(
            1 for f in window_frames
            if f["dst"].lower() == BROADCAST_MAC
        )

        self.logger.debug(
            f"[BroadcastDetector] dst={dst}, "
            f"broadcast frames in window={broadcast_count}"
        )

        # Any broadcast deauth is an immediate red flag
        if dst == BROADCAST_MAC or broadcast_count >= 1:
            return {
                "alert"   : True,
                "severity": "CRITICAL",
                "detail"  : (
                    f"Broadcast deauth detected! "
                    f"dst={frame['dst']} | "
                    f"{broadcast_count} broadcast frames in {self.window}s window"
                ),
            }
        return {"alert": False}
