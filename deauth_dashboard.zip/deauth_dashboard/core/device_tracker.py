"""
DeviceTracker — continuously pings tracked devices (webcam, IoT).
Emits status changes (online/offline) via SocketIO.
Detects disconnection caused by deauth attacks.
"""

import time
import threading
import subprocess
import platform


class DeviceTracker:
    POLL_INTERVAL = 3   # seconds between pings
    OFFLINE_AFTER = 2   # consecutive failures before marking offline

    def __init__(self, devices, emit_fn, logger):
        """
        devices: list of dicts — [{"ip": "192.168.1.100", "label": "IP Webcam", "icon": "📷"}]
        """
        self.emit_fn = emit_fn
        self.logger  = logger
        self._stop   = threading.Event()

        # Build internal state per device
        self._devices = {}
        for d in devices:
            ip = d["ip"]
            self._devices[ip] = {
                "ip"            : ip,
                "label"         : d.get("label", ip),
                "icon"          : d.get("icon", "📡"),
                "status"        : "unknown",   # online / offline / unknown
                "last_seen"     : None,
                "last_changed"  : None,
                "fail_streak"   : 0,
                "disconnect_count": 0,
            }

    def start(self):
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def stop(self):
        self._stop.set()

    def get_all(self):
        return list(self._devices.values())

    # ── Internal ────────────────────────────────────────────────────

    def _loop(self):
        while not self._stop.is_set():
            for ip, state in self._devices.items():
                alive = self._ping(ip)
                self._update(ip, alive)
            time.sleep(self.POLL_INTERVAL)

    def _ping(self, ip):
        """Returns True if host responds."""
        param = "-n" if platform.system().lower() == "windows" else "-c"
        try:
            result = subprocess.run(
                ["ping", param, "1", "-W", "1", ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _update(self, ip, alive):
        state = self._devices[ip]
        now   = time.strftime("%Y-%m-%d %H:%M:%S")
        prev_status = state["status"]

        if alive:
            state["fail_streak"] = 0
            state["last_seen"]   = now

            if prev_status != "online":
                state["status"]       = "online"
                state["last_changed"] = now
                self.logger.info(f"[DeviceTracker] {state['label']} ({ip}) → ONLINE")
                self._emit(state, event="device_online")
            else:
                self._emit(state, event="device_update")

        else:
            state["fail_streak"] += 1

            if state["fail_streak"] >= self.OFFLINE_AFTER:
                if prev_status != "offline":
                    state["status"]           = "offline"
                    state["last_changed"]     = now
                    state["disconnect_count"] += 1
                    self.logger.warning(
                        f"[DeviceTracker] {state['label']} ({ip}) → OFFLINE "
                        f"(disconnects: {state['disconnect_count']})"
                    )
                    self._emit(state, event="device_offline")
                else:
                    self._emit(state, event="device_update")

    def _emit(self, state, event="device_update"):
        payload = dict(state)
        payload["event"] = event
        self.emit_fn(payload)
