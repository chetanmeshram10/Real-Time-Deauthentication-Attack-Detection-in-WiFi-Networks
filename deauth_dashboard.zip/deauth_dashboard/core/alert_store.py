"""
AlertStore — thread-safe in-memory store for all detection alerts.
"""

import threading
from collections import defaultdict


class AlertStore:
    MAX_ALERTS = 500

    def __init__(self):
        self._alerts = []
        self._lock   = threading.Lock()

    def add(self, alert):
        with self._lock:
            self._alerts.append(alert)
            if len(self._alerts) > self.MAX_ALERTS:
                self._alerts = self._alerts[-self.MAX_ALERTS:]

    def get_all(self):
        with self._lock:
            return list(reversed(self._alerts))  # newest first

    def clear(self):
        with self._lock:
            self._alerts.clear()

    def get_stats(self):
        with self._lock:
            total = len(self._alerts)
            by_method   = defaultdict(int)
            by_severity = defaultdict(int)
            for a in self._alerts:
                by_method[a["method"]] += 1
                by_severity[a["severity"]] += 1
            return {
                "total"      : total,
                "by_method"  : dict(by_method),
                "by_severity": dict(by_severity),
            }
