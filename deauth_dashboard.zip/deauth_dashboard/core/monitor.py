"""
WiFiMonitor — captures deauth/disassoc frames,
routes through all 5 detectors, emits alerts via SocketIO.
"""

import time
import threading
from collections import deque
from scapy.all import sniff, Dot11, Dot11Deauth, Dot11Disas

from core.detectors.threshold    import ThresholdDetector
from core.detectors.broadcast    import BroadcastDetector
from core.detectors.rate_anomaly import RateAnomalyDetector
from core.detectors.rapid_seq    import RapidSequenceDetector
from core.detectors.reason_code  import ReasonCodeDetector


class WiFiMonitor:
    def __init__(self, interface, threshold, window,
                 baseline_period, emit_fn, logger):
        self.interface       = interface
        self.window          = window
        self.baseline_period = baseline_period
        self.emit_fn         = emit_fn
        self.logger          = logger
        self._running        = False
        self._frame_window   = deque()
        self._lock           = threading.Lock()
        self._baseline_end   = time.time() + baseline_period
        self._learning       = True
        self._alert_cooldown = {}   # method -> last alert time

        self.detectors = [
            ThresholdDetector(threshold=threshold, window=window, logger=logger),
            BroadcastDetector(window=window, logger=logger),
            RateAnomalyDetector(window=window, baseline_period=baseline_period, logger=logger),
            RapidSequenceDetector(window=window, logger=logger),
            ReasonCodeDetector(window=window, logger=logger),
        ]

    def start(self):
        self._running = True
        self.logger.info(f"[Monitor] Sniffing on {self.interface}")
        if self._learning:
            self.logger.info(f"[Monitor] Baseline learning for {self.baseline_period}s...")
        sniff(
            iface=self.interface,
            prn=self._handler,
            store=False,
            stop_filter=lambda _: not self._running,
        )

    def stop(self):
        self._running = False

    def _handler(self, pkt):
        if not (pkt.haslayer(Dot11Deauth) or pkt.haslayer(Dot11Disas)):
            return

        now   = time.time()
        src   = pkt[Dot11].addr2 or "ff:ff:ff:ff:ff:ff"
        dst   = pkt[Dot11].addr1 or "ff:ff:ff:ff:ff:ff"
        bssid = pkt[Dot11].addr3 or "ff:ff:ff:ff:ff:ff"

        if pkt.haslayer(Dot11Deauth):
            reason = pkt[Dot11Deauth].reason
            ftype  = "deauth"
        else:
            reason = pkt[Dot11Disas].reason
            ftype  = "disassoc"

        frame = {
            "time": now, "src": src, "dst": dst,
            "bssid": bssid, "reason": reason, "type": ftype,
        }

        # Baseline phase
        if self._learning and now < self._baseline_end:
            for d in self.detectors:
                if hasattr(d, "record_baseline"):
                    d.record_baseline(frame)
            return

        if self._learning:
            self._learning = False
            self.logger.info("[Monitor] Baseline complete — detection ACTIVE")

        # Update sliding window
        with self._lock:
            self._frame_window.append(frame)
            cutoff = now - self.window
            while self._frame_window and self._frame_window[0]["time"] < cutoff:
                self._frame_window.popleft()
            current = list(self._frame_window)

        # Run all 5 detectors
        for detector in self.detectors:
            result = detector.analyze(frame, current)
            if result["alert"]:
                # Per-method cooldown (5s) to avoid spam
                last = self._alert_cooldown.get(detector.name, 0)
                if now - last < 5:
                    continue
                self._alert_cooldown[detector.name] = now

                alert = {
                    "id"       : f"{int(now*1000)}-{detector.name[:4]}",
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "method"   : detector.name,
                    "severity" : result.get("severity", "HIGH"),
                    "detail"   : result["detail"],
                    "src"      : src,
                    "dst"      : dst,
                    "bssid"    : bssid,
                    "reason"   : reason,
                    "type"     : ftype,
                }
                self.logger.warning(
                    f"[ALERT] {detector.name} | {result['detail']} | src={src}"
                )
                self.emit_fn(alert)
